#pragma once

struct Dinoku
{
	double posX;
	double posY;
	double velX;
	double velY;
	double radius;
};

struct Ground
{
	double posX;
	double posY;
};

struct background
{
	double posX;
	double posY;
	double velX;
	double velY;
};

struct Wood
{
	double posX;
	double posY;
	double velX;
	double velY;
	double radius;
};